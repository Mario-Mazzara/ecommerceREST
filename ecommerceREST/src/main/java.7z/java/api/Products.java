package api;

import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;



import viewmodel.Product;

@ApplicationPath("/api")
@Path("/products")
public class Products extends Application {
	private DataSource dataSource = null;
	@GET
	@Produces("application/json")
	public List<Product> products(){
		try {
			dataSource = (DataSource)((Context)(new InitialContext()).lookup("java:comp/env")).lookup("jdbc/ecommerce");
			String productsQuery="SELECT ProductsTemp.id AS id, name, ProductsTemp.description, ProductsTypeTemp.description AS type, priceId "+
								"FROM ProductsTemp "+ 
								"INNER JOIN ProductsTypeTemp ON ProductsTemp.Id = ProductsTypeTemp.Id ";
			QueryRunner run = new QueryRunner(dataSource);
			ResultSetHandler<List<Product>> resultSetHandler = new BeanListHandler<Product>(Product.class);
			List<Product> products = run.query(productsQuery, resultSetHandler);		
			return products;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("eccezione");
			return null;
		}
		
	}
	
	@GET
	@Path("/{id}")
	@Produces("application/json")
	public Product productById(@PathParam("id") int id){
		try {
			dataSource = (DataSource)((Context)(new InitialContext()).lookup("java:comp/env")).lookup("jdbc/ecommerce");
			String productsQuery="SELECT ProductsTemp.id AS id, name, ProductsTemp.description, ProductsTypeTemp.description AS type, priceId "+
							"FROM ProductsTemp "+ 
							"INNER JOIN ProductsTypeTemp ON ProductsTemp.Id = ProductsTypeTemp.Id "+
							"WHERE ProductsTemp.id = ?"
							;
			QueryRunner run = new QueryRunner(dataSource);
			ResultSetHandler<Product> resultSetHandler = new BeanHandler<Product>(Product.class);
			Product product = run.query(productsQuery, resultSetHandler, id);
			return product;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	@POST
	@Consumes("application/json")
	public void product(@PathParam("product") Product product) {
		
	}
	
}
